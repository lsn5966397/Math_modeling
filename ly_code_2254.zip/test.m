function [z]=test(x,y)
x=x+2

y=y+5

z=x+y
end